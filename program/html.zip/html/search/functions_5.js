var searchData=
[
  ['leer',['leer',['../class_especie.html#a2335c9ddc4757e964d78e6267304cf52',1,'Especie::leer()'],['../class_individuo.html#af44a2acd2ee9c4f07f07e99d8b6e5ee9',1,'Individuo::leer()']]],
  ['leer_5farbol',['leer_arbol',['../class_poblacion.html#a7f97feb31099739bce88c4ad33e7f19b',1,'Poblacion']]]
];
