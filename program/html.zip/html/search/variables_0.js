var searchData=
[
  ['crom_5fn',['crom_n',['../class_individuo.html#a53ae1255e003cb3e0d5b91ba1b3e5fce',1,'Individuo']]],
  ['crom_5fs',['crom_s',['../class_individuo.html#a67db346c260476b88c32a4a953c29b56',1,'Individuo']]]
];
