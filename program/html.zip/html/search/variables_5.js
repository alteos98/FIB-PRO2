var searchData=
[
  ['padre',['padre',['../class_individuo.html#a0d75aa5ac6772ebd06ccc3dc06f5d0e5',1,'Individuo']]],
  ['primer_5fnode',['primer_node',['../class_arbre.html#a62818cdde6c1912a7c9a15db3b93d297',1,'Arbre']]]
];
