var searchData=
[
  ['individuo',['Individuo',['../class_individuo.html#a3042a660b9789ee24dd3658248c8e0b9',1,'Individuo']]]
];
