var searchData=
[
  ['xy',['xy',['../class_individuo.html#a77a4a575bd35e54fbc70b731127e96e7',1,'Individuo']]]
];
