var searchData=
[
  ['n',['N',['../class_especie.html#a69aad888b5b4e5ba5a12a7e343fada57',1,'Especie']]],
  ['nombre',['nombre',['../class_individuo.html#a684dc8cf134dc659d54196a6ffdc351f',1,'Individuo']]]
];
